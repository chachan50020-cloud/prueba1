import { type Booking, type InsertBooking, type Event, type InsertEvent, type NewsletterSubscriber, type InsertNewsletterSubscriber } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Booking methods
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookings(): Promise<Booking[]>;
  getBookingById(id: string): Promise<Booking | undefined>;
  updateBookingStatus(id: string, status: string): Promise<Booking | undefined>;
  
  // Event methods
  getEvents(): Promise<Event[]>;
  getActiveEvents(): Promise<Event[]>;
  getEventById(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<Event>): Promise<Event | undefined>;
  
  // Newsletter methods
  subscribeToNewsletter(subscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber>;
  getNewsletterSubscribers(): Promise<NewsletterSubscriber[]>;
  isEmailSubscribed(email: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private bookings: Map<string, Booking>;
  private events: Map<string, Event>;
  private newsletterSubscribers: Map<string, NewsletterSubscriber>;

  constructor() {
    this.bookings = new Map();
    this.events = new Map();
    this.newsletterSubscribers = new Map();
    
    // Initialize with some sample events
    this.initializeEvents();
  }

  private initializeEvents() {
    const sampleEvents: Event[] = [
      {
        id: randomUUID(),
        title: "Día de Adopción Especial",
        description: "Un evento especial para conectar gatos rescatados con familias amorosas. Incluye evaluaciones gratuitas, asesoría especializada y descuentos en servicios.",
        date: "2025-01-15",
        time: "10:00 AM - 4:00 PM",
        price: 0,
        isFree: true,
        imageUrl: "https://images.unsplash.com/photo-1573865526739-10659fec78a5",
        category: "adopción",
        maxAttendees: 50,
        currentAttendees: 12,
        isActive: true,
      },
      {
        id: randomUUID(),
        title: "Taller: Comportamiento Felino",
        description: "Aprende a entender mejor a tu gato con nuestros expertos en comportamiento animal.",
        date: "2025-01-22",
        time: "6:00 PM - 8:00 PM",
        price: 50000,
        isFree: false,
        imageUrl: "https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd",
        category: "educación",
        maxAttendees: 20,
        currentAttendees: 8,
        isActive: true,
      },
      {
        id: randomUUID(),
        title: "Sesión de Fotos San Valentín",
        description: "Sesión profesional de fotos temática para tu gato con decoración especial.",
        date: "2025-02-14",
        time: "Todo el día",
        price: 80000,
        isFree: false,
        imageUrl: "https://images.unsplash.com/photo-1518717758536-85ae29035b6d",
        category: "fotografía",
        maxAttendees: 15,
        currentAttendees: 3,
        isActive: true,
      },
      {
        id: randomUUID(),
        title: "Jornada de Salud Gratuita",
        description: "Chequeos veterinarios básicos gratuitos y charlas sobre prevención de enfermedades.",
        date: "2025-03-05",
        time: "9:00 AM - 3:00 PM",
        price: 0,
        isFree: true,
        imageUrl: "https://pixabay.com/get/g23d357acc363e11abb6563d6ea21e32b",
        category: "salud",
        maxAttendees: 40,
        currentAttendees: 15,
        isActive: true,
      }
    ];

    sampleEvents.forEach(event => {
      this.events.set(event.id, event);
    });
  }

  // Booking methods
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = {
      ...insertBooking,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async getBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async getBookingById(id: string): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async updateBookingStatus(id: string, status: string): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (booking) {
      booking.status = status;
      this.bookings.set(id, booking);
      return booking;
    }
    return undefined;
  }

  // Event methods
  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  async getActiveEvents(): Promise<Event[]> {
    return Array.from(this.events.values()).filter(event => event.isActive);
  }

  async getEventById(id: string): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const event: Event = {
      ...insertEvent,
      id,
      currentAttendees: 0,
    };
    this.events.set(id, event);
    return event;
  }

  async updateEvent(id: string, eventUpdate: Partial<Event>): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (event) {
      const updatedEvent = { ...event, ...eventUpdate };
      this.events.set(id, updatedEvent);
      return updatedEvent;
    }
    return undefined;
  }

  // Newsletter methods
  async subscribeToNewsletter(insertSubscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber> {
    const id = randomUUID();
    const subscriber: NewsletterSubscriber = {
      ...insertSubscriber,
      id,
      subscribedAt: new Date(),
    };
    this.newsletterSubscribers.set(subscriber.email, subscriber);
    return subscriber;
  }

  async getNewsletterSubscribers(): Promise<NewsletterSubscriber[]> {
    return Array.from(this.newsletterSubscribers.values());
  }

  async isEmailSubscribed(email: string): Promise<boolean> {
    return this.newsletterSubscribers.has(email);
  }
}

export const storage = new MemStorage();
