from django.db import models
from django.utils import timezone
import uuid

class Booking(models.Model):
    SERVICIO_CHOICES = [
        ('hospedaje', 'Hospedaje'),
        ('estetica', 'Estética'),
        ('medicina-preventiva', 'Medicina Preventiva'),
        ('cuidado-casa', 'Cuidado en Casa'),
    ]
    
    ESTADO_CHOICES = [
        ('pending', 'Pendiente'),
        ('confirmed', 'Confirmada'),
        ('completed', 'Completada'),
        ('cancelled', 'Cancelada'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    service = models.CharField(max_length=50, choices=SERVICIO_CHOICES)
    cat_name = models.CharField(max_length=100)
    owner_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True, null=True)
    date = models.DateField()
    time = models.CharField(max_length=10)
    special_notes = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='pending')
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.cat_name} - {self.service} - {self.date}"

class Event(models.Model):
    CATEGORIA_CHOICES = [
        ('adopcion', 'Adopción'),
        ('educacion', 'Educación'),
        ('fotografia', 'Fotografía'),
        ('salud', 'Salud'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateField()
    time = models.CharField(max_length=50)
    price = models.PositiveIntegerField(default=0)
    is_free = models.BooleanField(default=False)
    image_url = models.URLField(blank=True, null=True)
    category = models.CharField(max_length=20, choices=CATEGORIA_CHOICES)
    max_attendees = models.PositiveIntegerField(blank=True, null=True)
    current_attendees = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['date']
    
    def __str__(self):
        return self.title

class NewsletterSubscriber(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-subscribed_at']
    
    def __str__(self):
        return self.email
