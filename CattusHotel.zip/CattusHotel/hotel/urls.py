from django.urls import path
from . import views

app_name = 'hotel'

urlpatterns = [
    path('', views.home, name='home'),
    path('servicios/', views.servicios, name='servicios'),
    path('eventos/', views.eventos, name='eventos'),
    path('alianzas/', views.alianzas, name='alianzas'),
    
    # API endpoints
    path('api/booking/', views.create_booking, name='create_booking'),
    path('api/newsletter/', views.subscribe_newsletter, name='subscribe_newsletter'),
    path('api/events/', views.events_api, name='events_api'),
]