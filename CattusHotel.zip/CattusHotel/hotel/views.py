from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.utils.dateparse import parse_date
import json
from .models import Booking, Event, NewsletterSubscriber

def home(request):
    """Vista principal que muestra todas las secciones"""
    events = Event.objects.filter(is_active=True)[:6]
    context = {
        'events': events,
    }
    return render(request, 'hotel/home.html', context)

def servicios(request):
    """Vista de servicios"""
    return render(request, 'hotel/servicios.html')

def eventos(request):
    """Vista de eventos"""
    events = Event.objects.filter(is_active=True)
    context = {
        'events': events,
    }
    return render(request, 'hotel/eventos.html', context)

def alianzas(request):
    """Vista de alianzas estratégicas"""
    return render(request, 'hotel/alianzas.html')

@csrf_exempt
def create_booking(request):
    """Crear una nueva reserva"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            booking = Booking.objects.create(
                service=data.get('service'),
                cat_name=data.get('cat_name'),
                owner_name=data.get('owner_name'),
                phone=data.get('phone'),
                email=data.get('email'),
                date=parse_date(data.get('date')),
                time=data.get('time'),
                special_notes=data.get('special_notes', ''),
            )
            
            return JsonResponse({
                'success': True,
                'message': 'Reserva creada exitosamente',
                'booking_id': str(booking.id)
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': 'Error al crear la reserva'
            }, status=400)
    
    return JsonResponse({'success': False, 'message': 'Método no permitido'}, status=405)

@csrf_exempt
def subscribe_newsletter(request):
    """Suscribirse al boletín"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            email = data.get('email')
            
            if not email:
                return JsonResponse({
                    'success': False,
                    'message': 'Email requerido'
                }, status=400)
            
            subscriber, created = NewsletterSubscriber.objects.get_or_create(email=email)
            
            if created:
                return JsonResponse({
                    'success': True,
                    'message': 'Suscripción exitosa'
                })
            else:
                return JsonResponse({
                    'success': False,
                    'message': 'Email ya está suscrito'
                }, status=400)
                
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': 'Error al procesar suscripción'
            }, status=400)
    
    return JsonResponse({'success': False, 'message': 'Método no permitido'}, status=405)

def events_api(request):
    """API para obtener eventos"""
    events = Event.objects.filter(is_active=True).values()
    events_list = list(events)
    
    # Convertir UUIDs a strings
    for event in events_list:
        event['id'] = str(event['id'])
        event['date'] = event['date'].strftime('%Y-%m-%d')
    
    return JsonResponse(events_list, safe=False)
