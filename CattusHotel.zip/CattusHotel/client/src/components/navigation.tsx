import { useState, useEffect } from "react";
import { Cat, Menu, X, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("inicio");

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["inicio", "servicios", "alianzas", "eventos"];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom > 100;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  const scrollToBooking = () => {
    const element = document.getElementById("booking-system");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav 
      className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50"
      data-testid="navigation"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Cat className="text-cattus-purple text-2xl mr-2" data-testid="logo-icon" />
            <span className="text-xl font-bold text-gray-900" data-testid="logo-text">
              Cattus Hotel
            </span>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {[
                { id: "inicio", label: "Inicio" },
                { id: "servicios", label: "Servicios" },
                { id: "alianzas", label: "Alianzas" },
                { id: "eventos", label: "Eventos" },
              ].map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => scrollToSection(id)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeSection === id
                      ? "text-cattus-purple"
                      : "text-gray-900 hover:text-cattus-purple"
                  }`}
                  data-testid={`nav-link-${id}`}
                >
                  {label}
                </button>
              ))}
              <Button
                onClick={scrollToBooking}
                className="bg-cattus-purple text-white hover:bg-cattus-purple-light"
                data-testid="button-reserve"
              >
                <Calendar className="mr-2 h-4 w-4" />
                Reservar
              </Button>
            </div>
          </div>
          
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t" data-testid="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {[
              { id: "inicio", label: "Inicio" },
              { id: "servicios", label: "Servicios" },
              { id: "alianzas", label: "Alianzas" },
              { id: "eventos", label: "Eventos" },
            ].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => scrollToSection(id)}
                className="block w-full text-left px-3 py-2 text-gray-900 hover:bg-gray-100 rounded-md"
                data-testid={`mobile-nav-link-${id}`}
              >
                {label}
              </button>
            ))}
            <Button
              onClick={scrollToBooking}
              className="w-full mt-2 bg-cattus-purple text-white hover:bg-cattus-purple-light"
              data-testid="mobile-button-reserve"
            >
              <Calendar className="mr-2 h-4 w-4" />
              Reservar
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}
