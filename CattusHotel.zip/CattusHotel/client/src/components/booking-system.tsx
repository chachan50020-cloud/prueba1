import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar as CalendarIcon, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema, type InsertBooking } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const timeSlots = ["9:00", "11:00", "14:00", "16:00"];

export default function BookingSystem() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<InsertBooking>({
    resolver: zodResolver(insertBookingSchema),
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: InsertBooking) => {
      const response = await apiRequest("POST", "/api/bookings", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "¡Reserva confirmada!",
        description: "Tu reserva ha sido creada exitosamente. Te contactaremos pronto.",
      });
      reset();
      setSelectedDate(undefined);
      setSelectedTime("");
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo crear la reserva. Por favor intenta nuevamente.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBooking) => {
    if (!selectedDate || !selectedTime) {
      toast({
        title: "Error",
        description: "Por favor selecciona fecha y hora.",
        variant: "destructive",
      });
      return;
    }

    const bookingData = {
      ...data,
      date: format(selectedDate, "yyyy-MM-dd"),
      time: selectedTime,
    };

    createBookingMutation.mutate(bookingData);
  };

  const generateCalendarDays = () => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
    
    const days = [];
    
    // Previous month days
    for (let i = firstDayOfMonth - 1; i >= 0; i--) {
      const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
      const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
      const prevMonthDays = new Date(prevYear, prevMonth + 1, 0).getDate();
      days.push({
        day: prevMonthDays - i,
        isCurrentMonth: false,
        date: new Date(prevYear, prevMonth, prevMonthDays - i)
      });
    }
    
    // Current month days
    for (let day = 1; day <= daysInMonth; day++) {
      days.push({
        day,
        isCurrentMonth: true,
        date: new Date(currentYear, currentMonth, day)
      });
    }
    
    return days;
  };

  const calendarDays = generateCalendarDays();

  return (
    <Card id="booking-system" className="bg-white rounded-3xl shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-gray-900 text-center">
          <CalendarIcon className="text-cattus-purple mr-2 inline" />
          Sistema de Reservas
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Calendar Section */}
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-calendar-title">
              Selecciona Fecha y Hora
            </h4>
            <div className="bg-gray-50 rounded-xl p-6">
              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2 mb-4">
                {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map(day => (
                  <div key={day} className="text-center text-sm font-medium text-gray-600 p-2">
                    {day}
                  </div>
                ))}
                {calendarDays.map((dayObj, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => {
                      if (dayObj.isCurrentMonth && dayObj.date >= new Date()) {
                        setSelectedDate(dayObj.date);
                      }
                    }}
                    className={`text-center p-2 text-sm rounded cursor-pointer transition-colors ${
                      !dayObj.isCurrentMonth
                        ? "text-gray-400"
                        : dayObj.date < new Date()
                        ? "text-gray-400 cursor-not-allowed"
                        : selectedDate && format(selectedDate, "yyyy-MM-dd") === format(dayObj.date, "yyyy-MM-dd")
                        ? "bg-cattus-purple text-white"
                        : "text-gray-900 hover:bg-cattus-purple hover:text-white"
                    }`}
                    disabled={!dayObj.isCurrentMonth || dayObj.date < new Date()}
                    data-testid={`button-calendar-day-${dayObj.day}`}
                  >
                    {dayObj.day}
                  </button>
                ))}
              </div>
              
              {/* Time Slots */}
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map(time => (
                  <button
                    key={time}
                    type="button"
                    onClick={() => setSelectedTime(time)}
                    className={`text-sm py-2 px-3 border border-gray-300 rounded transition-colors ${
                      selectedTime === time
                        ? "bg-cattus-purple text-white border-cattus-purple"
                        : "bg-white hover:bg-cattus-purple hover:text-white hover:border-cattus-purple"
                    }`}
                    data-testid={`button-time-${time}`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-booking-form-title">
              Información de Reserva
            </h4>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="service">Servicio</Label>
                <Controller
                  name="service"
                  control={control}
                  render={({ field }) => (
                    <Select onValueChange={field.onChange} value={field.value}>
                      <SelectTrigger data-testid="select-service">
                        <SelectValue placeholder="Selecciona un servicio" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hospedaje">Hospedaje</SelectItem>
                        <SelectItem value="estetica">Estética</SelectItem>
                        <SelectItem value="medicina-preventiva">Medicina Preventiva</SelectItem>
                        <SelectItem value="cuidado-casa">Cuidado en Casa</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
                {errors.service && (
                  <p className="text-red-500 text-sm mt-1" data-testid="error-service">
                    {errors.service.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="catName">Nombre del Gato</Label>
                <Input
                  {...register("catName")}
                  placeholder="Ej: Misu"
                  data-testid="input-cat-name"
                />
                {errors.catName && (
                  <p className="text-red-500 text-sm mt-1" data-testid="error-cat-name">
                    {errors.catName.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="ownerName">Tu Nombre</Label>
                <Input
                  {...register("ownerName")}
                  placeholder="Nombre completo"
                  data-testid="input-owner-name"
                />
                {errors.ownerName && (
                  <p className="text-red-500 text-sm mt-1" data-testid="error-owner-name">
                    {errors.ownerName.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="phone">Teléfono</Label>
                <Input
                  {...register("phone")}
                  type="tel"
                  placeholder="+57 300 123 4567"
                  data-testid="input-phone"
                />
                {errors.phone && (
                  <p className="text-red-500 text-sm mt-1" data-testid="error-phone">
                    {errors.phone.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="email">Email (Opcional)</Label>
                <Input
                  {...register("email")}
                  type="email"
                  placeholder="tu@email.com"
                  data-testid="input-email"
                />
              </div>

              <div>
                <Label htmlFor="specialNotes">Notas Especiales</Label>
                <Textarea
                  {...register("specialNotes")}
                  rows={3}
                  placeholder="Información especial sobre tu gato..."
                  data-testid="textarea-special-notes"
                />
              </div>

              <Button
                type="submit"
                disabled={createBookingMutation.isPending}
                className="w-full bg-cattus-purple text-white py-3 rounded-lg hover:bg-cattus-purple-light transition-colors font-semibold"
                data-testid="button-submit-booking"
              >
                {createBookingMutation.isPending ? (
                  "Procesando..."
                ) : (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Confirmar Reserva
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
