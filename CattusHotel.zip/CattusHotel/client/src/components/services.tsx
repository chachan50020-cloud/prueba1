import { Bed, Scissors, Stethoscope, Home, Calendar, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import BookingSystem from "@/components/booking-system";

export default function Services() {
  const services = [
    {
      title: "Hospedaje",
      description: "Suites cómodas y seguras para estadías cortas o largas. Cada habitación incluye área de descanso, juguetes y acceso a jardín interior.",
      price: "45.000",
      currency: "$",
      period: "/día",
      icon: Bed,
      color: "bg-cattus-purple",
      hoverColor: "hover:bg-cattus-purple-light",
      image: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      features: [
        "Suites privadas con vista al jardín",
        "Supervisión 24/7 por personal especializado",
        "Alimentación personalizada"
      ]
    },
    {
      title: "Estética",
      description: "Servicios de grooming especializado que incluyen baño, corte de uñas, cepillado y tratamientos de spa relajantes.",
      price: "35.000",
      currency: "$",
      period: "",
      icon: Scissors,
      color: "bg-cattus-blue",
      hoverColor: "hover:bg-blue-600",
      image: "https://pixabay.com/get/gf1b5aa2d5e497f9166646b98c26b64b7006451b10b26d4619c387c0a50e41386678f6d5cf7a5ade5b2445c576881f6cb5ca5f2262a16631269f78e86aedb22f0_1280.jpg",
      features: [
        "Baño con productos hipoalergénicos",
        "Corte de uñas y limpieza de oídos",
        "Tratamientos anti-estrés"
      ]
    },
    {
      title: "Medicina Preventiva",
      description: "Cuidados médicos preventivos incluyendo revisiones generales, vacunación y desparasitación para mantener la salud óptima.",
      price: "Variable",
      currency: "",
      period: "",
      icon: Stethoscope,
      color: "bg-green-500",
      hoverColor: "hover:bg-green-600",
      image: "https://pixabay.com/get/g87ff6fca8ef550d107fc25210ad9d12124506192ac4ba325c083b4d4d14e9ce1551a5a204f5e8834710a65d051a089400d40c82bdb226d919a8d1c790f718e1d_1280.jpg",
      features: [],
      subServices: [
        { name: "Revisión General", price: "25.000" },
        { name: "Vacunación", price: "30.000" },
        { name: "Desparasitación", price: "20.000" }
      ]
    },
    {
      title: "Cuidado en Casa",
      description: "Servicio personalizado en el hogar para gatos que prefieren su ambiente familiar. Minimiza el estrés y mantiene las rutinas habituales.",
      price: "25.000",
      currency: "$",
      period: "/visita",
      icon: Home,
      color: "bg-yellow-500",
      hoverColor: "hover:bg-yellow-600",
      image: "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      features: [
        "Visitas programadas según necesidad",
        "Alimentación y medicación",
        "Reportes diarios con fotos"
      ]
    }
  ];

  const scrollToBooking = () => {
    const element = document.getElementById("booking-system");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="py-20 bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 
            className="text-4xl font-bold text-gray-900 mb-4"
            data-testid="text-services-title"
          >
            Nuestros Servicios
          </h2>
          <p 
            className="text-xl text-gray-600"
            data-testid="text-services-subtitle"
          >
            Cuidado integral diseñado especialmente para gatos
          </p>
        </div>
        
        {/* Services Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300"
              data-testid={`card-service-${index}`}
            >
              <img
                src={service.image}
                alt={`Servicio de ${service.title}`}
                className="w-full h-64 object-cover"
                data-testid={`img-service-${index}`}
              />
              <div className="p-8">
                <div className="flex items-center mb-4">
                  <div className={`${service.color} p-3 rounded-full mr-4`}>
                    <service.icon className="text-white text-xl" size={24} />
                  </div>
                  <h3 
                    className="text-2xl font-bold text-gray-900"
                    data-testid={`text-service-title-${index}`}
                  >
                    {service.title}
                  </h3>
                </div>
                <p 
                  className="text-gray-600 mb-6"
                  data-testid={`text-service-description-${index}`}
                >
                  {service.description}
                </p>
                
                {service.subServices ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    {service.subServices.map((subService, subIndex) => (
                      <div 
                        key={subIndex}
                        className="text-center p-4 bg-gray-50 rounded-lg"
                        data-testid={`card-subservice-${index}-${subIndex}`}
                      >
                        <div className="font-semibold text-sm" data-testid={`text-subservice-name-${index}-${subIndex}`}>
                          {subService.name}
                        </div>
                        <div className="text-xs text-gray-600" data-testid={`text-subservice-price-${index}-${subIndex}`}>
                          ${subService.price}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <div 
                        key={featureIndex}
                        className="flex items-center text-sm text-gray-700"
                        data-testid={`text-service-feature-${index}-${featureIndex}`}
                      >
                        <Check className="text-green-500 mr-2" size={16} />
                        {feature}
                      </div>
                    ))}
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <div 
                    className="text-2xl font-bold text-gray-900"
                    data-testid={`text-service-price-${index}`}
                  >
                    {service.currency}{service.price}{service.period}
                  </div>
                  <Button
                    onClick={scrollToBooking}
                    className={`${service.color} text-white px-6 py-2 rounded-lg ${service.hoverColor} transition-colors`}
                    data-testid={`button-service-book-${index}`}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {service.title === "Medicina Preventiva" ? "Programar" : 
                     service.title === "Cuidado en Casa" ? "Consultar" : "Reservar"}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Booking System */}
        <BookingSystem />
      </div>
    </div>
  );
}
