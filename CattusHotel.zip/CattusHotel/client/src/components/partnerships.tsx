import { Handshake, DraftingCompass, Wrench, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Partnerships() {
  const partnershipServices = [
    {
      title: "Diseño Personalizado",
      description: "Espacios únicos diseñados específicamente para las necesidades de cada gato y ambiente.",
      icon: DraftingCompass,
      color: "bg-cattus-purple",
    },
    {
      title: "Fabricación Especializada",
      description: "Construcción con materiales seguros y resistentes, pensados para la durabilidad y comodidad.",
      icon: Wrench,
      color: "bg-cattus-blue",
    },
    {
      title: "Materiales Eco-Friendly",
      description: "Uso de materiales sostenibles y seguros para la salud de los felinos y el medio ambiente.",
      icon: Leaf,
      color: "bg-green-500",
    },
  ];

  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 
            className="text-4xl font-bold text-gray-900 mb-4"
            data-testid="text-partnerships-title"
          >
            Alianzas Estratégicas
          </h2>
          <p 
            className="text-xl text-gray-600"
            data-testid="text-partnerships-subtitle"
          >
            Colaboramos con los mejores para ofrecer servicios excepcionales
          </p>
        </div>

        {/* Gatopia Col Partnership */}
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-3xl p-8 lg:p-12 mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="bg-cattus-purple p-4 rounded-full mr-4">
                  <Handshake className="text-white text-2xl" size={32} />
                </div>
                <div>
                  <h3 
                    className="text-3xl font-bold text-gray-900"
                    data-testid="text-partner-name"
                  >
                    Gatopia Col
                  </h3>
                  <p 
                    className="text-cattus-purple font-semibold text-lg"
                    data-testid="text-partner-specialty"
                  >
                    Espacios Arquitectónicos Especializados
                  </p>
                </div>
              </div>
              <div className="space-y-4 text-gray-700">
                <p 
                  className="text-lg"
                  data-testid="text-partner-description-1"
                >
                  Gatopia Col es nuestra alianza principal para el diseño y fabricación de espacios arquitectónicos especializados en el cuidado y bienestar felino.
                </p>
                <p data-testid="text-partner-description-2">
                  Esta empresa colombiana se especializa en crear ambientes únicos que respetan los instintos naturales de los gatos, combinando funcionalidad, seguridad y estética moderna.
                </p>
              </div>
              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div 
                    className="text-2xl font-bold text-cattus-purple"
                    data-testid="text-projects-count"
                  >
                    50+
                  </div>
                  <div 
                    className="text-sm text-gray-600"
                    data-testid="text-projects-label"
                  >
                    Proyectos Colaborativos
                  </div>
                </div>
                <div className="text-center">
                  <div 
                    className="text-2xl font-bold text-cattus-blue"
                    data-testid="text-partnership-duration"
                  >
                    3 años
                  </div>
                  <div 
                    className="text-sm text-gray-600"
                    data-testid="text-partnership-label"
                  >
                    De Partnership
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1531844251246-9a1bfaae09fc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="Gatopia Col Designs"
                className="rounded-2xl shadow-2xl"
                data-testid="img-partner-showcase"
              />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg">
                <div className="text-sm font-semibold text-gray-900">Gatopia Col</div>
                <div className="text-xs text-gray-600">Diseño Especializado</div>
              </div>
            </div>
          </div>
        </div>

        {/* Services Offered Together */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {partnershipServices.map((service, index) => (
            <div
              key={index}
              className="text-center p-6 bg-gray-50 rounded-2xl hover:shadow-lg transition-shadow"
              data-testid={`card-partnership-service-${index}`}
            >
              <div className={`${service.color} p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center`}>
                <service.icon className="text-white text-xl" size={24} />
              </div>
              <h4 
                className="text-xl font-semibold mb-3"
                data-testid={`text-partnership-service-title-${index}`}
              >
                {service.title}
              </h4>
              <p 
                className="text-gray-600"
                data-testid={`text-partnership-service-description-${index}`}
              >
                {service.description}
              </p>
            </div>
          ))}
        </div>

        {/* Contact for Partnership */}
        <div className="mt-12 text-center">
          <div className="gradient-cattus rounded-2xl p-8 text-white">
            <h4 
              className="text-2xl font-bold mb-4"
              data-testid="text-partnership-cta-title"
            >
              ¿Interesado en Nuestros Servicios de Diseño?
            </h4>
            <p 
              className="text-lg mb-6"
              data-testid="text-partnership-cta-description"
            >
              Junto a Gatopia Col, creamos espacios únicos para hoteles, veterinarias y hogares.
            </p>
            <Button
              className="bg-white text-cattus-purple px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              data-testid="button-partnership-contact"
            >
              <Handshake className="mr-2 h-4 w-4" />
              Contactar para Proyectos
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
