import { Star } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Patricia Morales",
      petName: "Misu",
      content: "Misu estuvo súper cómodo durante mi viaje. El personal es increíblemente cariñoso y profesional. Definitivamente regresaré.",
      image: "https://pixabay.com/get/g3dd8e49fcb27be276505dff6824ef6e3b76b036e00f69b0b100bd105203a568ae2f980b4ac3c0c7b479b25d3a0a65146ced2d2b8cf58e2acb2fb9a92c4dfecbe_1280.jpg",
    },
    {
      name: "Roberto Silva",
      petName: "Felix y Luna",
      content: "El servicio de medicina preventiva es excepcional. Encontraron un problema de salud temprano que mi veterinario había pasado por alto.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
    },
    {
      name: "Carmen Jiménez",
      petName: "Whiskers",
      content: "Mi gata siempre regresa a casa relajada y feliz. Las instalaciones son de primera calidad y el personal ama genuinamente a los animales.",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
    },
  ];

  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 
            className="text-4xl font-bold text-gray-900 mb-4"
            data-testid="text-testimonials-title"
          >
            Clientes Felices
          </h2>
          <p 
            className="text-xl text-gray-600"
            data-testid="text-testimonials-subtitle"
          >
            Lo que dicen nuestros clientes sobre nosotros
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-2xl p-8 hover:shadow-lg transition-shadow"
              data-testid={`card-testimonial-${index}`}
            >
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400" data-testid={`rating-${index}`}>
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>
              </div>
              <p 
                className="text-gray-700 mb-6 italic"
                data-testid={`text-testimonial-content-${index}`}
              >
                "{testimonial.content}"
              </p>
              <div className="flex items-center">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                  data-testid={`img-testimonial-${index}`}
                />
                <div>
                  <div 
                    className="font-semibold"
                    data-testid={`text-testimonial-name-${index}`}
                  >
                    {testimonial.name}
                  </div>
                  <div 
                    className="text-sm text-gray-600"
                    data-testid={`text-testimonial-pet-${index}`}
                  >
                    Dueña de {testimonial.petName}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
