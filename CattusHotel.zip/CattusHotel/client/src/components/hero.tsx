import { Button } from "@/components/ui/button";
import { Calendar, Play } from "lucide-react";

export default function Hero() {
  const scrollToBooking = () => {
    const element = document.getElementById("booking-system");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToFacilities = () => {
    const element = document.getElementById("facilities");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-cattus-purple/80 to-cattus-blue/80"></div>
      <img
        src="https://images.unsplash.com/photo-1574144611937-0df059b5ef3e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2000&h=1200"
        alt="Cattus Hotel Interior"
        className="absolute inset-0 w-full h-full object-cover"
        data-testid="img-hero-background"
      />
      <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
        <h1 
          className="text-5xl md:text-7xl font-bold mb-6"
          data-testid="text-hero-title"
        >
          Cattus Hotel
        </h1>
        <p 
          className="text-xl md:text-2xl mb-8 font-light"
          data-testid="text-hero-subtitle"
        >
          El hogar perfecto para tu minino mientras no estás
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={scrollToBooking}
            className="bg-white text-cattus-purple px-8 py-4 text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105"
            data-testid="button-hero-reserve"
          >
            <Calendar className="mr-2 h-5 w-5" />
            Reservar Ahora
          </Button>
          <Button
            onClick={scrollToFacilities}
            className="bg-white text-cattus-purple px-8 py-4 text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105"
            data-testid="button-hero-facilities"
          >
            <Play className="mr-2 h-5 w-5" />
            Ver Instalaciones
          </Button>
        </div>
      </div>
    </div>
  );
}
