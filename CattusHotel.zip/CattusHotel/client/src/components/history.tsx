export default function History() {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 
              className="text-4xl font-bold text-gray-900 mb-6"
              data-testid="text-history-title"
            >
              Nuestra Historia
            </h2>
            <div className="space-y-6 text-lg text-gray-700">
              <p data-testid="text-history-paragraph-1">
                Cattus Hotel nació en 2018 del amor profundo por los felinos y la necesidad de crear un espacio donde los gatos pudieran sentirse como en casa, incluso cuando sus familias humanas no estuvieran presentes.
              </p>
              <p data-testid="text-history-paragraph-2">
                Fundado por un equipo de veterinarios y especialistas en comportamiento felino, nuestro hotel ha crecido hasta convertirse en el referente de cuidado especializado para gatos en la ciudad.
              </p>
              <p data-testid="text-history-paragraph-3">
                Cada detalle de nuestras instalaciones ha sido pensado para reducir el estrés y maximizar el bienestar de nuestros huéspedes felinos, creando un ambiente que respeta sus instintos naturales y personalidad única.
              </p>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1559190394-df5a28aab5c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=1000"
              alt="Historia Cattus Hotel"
              className="rounded-2xl shadow-2xl"
              data-testid="img-history"
            />
            <div className="absolute -bottom-6 -left-6 bg-cattus-purple text-white p-6 rounded-2xl">
              <div className="text-3xl font-bold" data-testid="text-years-experience">5+</div>
              <div className="text-sm" data-testid="text-years-label">Años de experiencia</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
