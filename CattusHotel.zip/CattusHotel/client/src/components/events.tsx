import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar, Clock, MapPin, Users, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Event } from "@shared/schema";

export default function Events() {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const newsletterMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await apiRequest("POST", "/api/newsletter/subscribe", { email });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "¡Suscripción exitosa!",
        description: "Te mantendremos informado sobre nuestros eventos.",
      });
      setNewsletterEmail("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo procesar la suscripción.",
        variant: "destructive",
      });
    },
  });

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      newsletterMutation.mutate(newsletterEmail);
    }
  };

  const featuredEvent = events?.find(event => event.title.includes("Adopción"));
  const upcomingEvents = events?.filter(event => !event.title.includes("Adopción")) || [];

  const formatPrice = (price: number, isFree: boolean) => {
    if (isFree) return "GRATIS";
    return `$${price.toLocaleString()}`;
  };

  const getBadgeColor = (category: string) => {
    switch (category) {
      case "adopción": return "bg-red-500";
      case "educación": return "bg-blue-500";
      case "fotografía": return "bg-pink-500";
      case "salud": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };

  if (isLoading) {
    return (
      <div className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-lg">Cargando eventos...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 
            className="text-4xl font-bold text-gray-900 mb-4"
            data-testid="text-events-title"
          >
            Eventos Especiales
          </h2>
          <p 
            className="text-xl text-gray-600"
            data-testid="text-events-subtitle"
          >
            Actividades y eventos especiales para gatos y sus familias
          </p>
        </div>

        {/* Featured Event */}
        {featuredEvent && (
          <Card className="bg-white rounded-3xl shadow-xl overflow-hidden mb-12">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 lg:p-12">
                <div className="flex items-center mb-4">
                  <Badge 
                    className={`${getBadgeColor(featuredEvent.category)} text-white px-3 py-1 rounded-full text-sm font-semibold mr-3`}
                    data-testid="badge-featured-event"
                  >
                    PRÓXIMO
                  </Badge>
                  <div 
                    className="text-gray-600"
                    data-testid="text-featured-event-date"
                  >
                    {featuredEvent.date}
                  </div>
                </div>
                <h3 
                  className="text-3xl font-bold text-gray-900 mb-4"
                  data-testid="text-featured-event-title"
                >
                  {featuredEvent.title}
                </h3>
                <p 
                  className="text-gray-600 text-lg mb-6"
                  data-testid="text-featured-event-description"
                >
                  {featuredEvent.description}
                </p>
                <div className="space-y-3 mb-8">
                  <div className="flex items-center text-gray-700">
                    <Clock className="text-cattus-purple mr-3" size={20} />
                    <span data-testid="text-featured-event-time">{featuredEvent.time}</span>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <MapPin className="text-cattus-blue mr-3" size={20} />
                    <span data-testid="text-featured-event-location">Instalaciones Cattus Hotel</span>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Users className="text-green-500 mr-3" size={20} />
                    <span data-testid="text-featured-event-registration">
                      {featuredEvent.isFree ? "Evento gratuito - Registro requerido" : "Registro requerido"}
                    </span>
                  </div>
                </div>
                <Button
                  className="bg-cattus-purple text-white px-6 py-3 rounded-lg hover:bg-cattus-purple-light transition-colors font-semibold"
                  data-testid="button-featured-event-register"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  Registrarse
                </Button>
              </div>
              <div className="relative">
                <img
                  src={featuredEvent.imageUrl || "https://images.unsplash.com/photo-1573865526739-10659fec78a5"}
                  alt={featuredEvent.title}
                  className="w-full h-full object-cover"
                  data-testid="img-featured-event"
                />
                <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg">
                  <div 
                    className="text-sm font-semibold text-gray-900"
                    data-testid="text-featured-event-attendees"
                  >
                    {featuredEvent.currentAttendees}+ Participantes
                  </div>
                  <div className="text-xs text-gray-600">Ya inscritos</div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Upcoming Events Grid */}
        {upcomingEvents.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {upcomingEvents.map((event, index) => (
              <Card
                key={event.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
                data-testid={`card-event-${index}`}
              >
                <img
                  src={event.imageUrl || "https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd"}
                  alt={event.title}
                  className="w-full h-48 object-cover"
                  data-testid={`img-event-${index}`}
                />
                <CardContent className="p-6">
                  <div className="flex items-center mb-2">
                    <Badge 
                      className={`${getBadgeColor(event.category)} text-white px-2 py-1 rounded text-xs font-semibold mr-2`}
                      data-testid={`badge-event-${index}`}
                    >
                      {event.date.split('-').reverse().join(' ').replace(' ', ' ').replace(' ', ' ')}
                    </Badge>
                    <div 
                      className="text-sm text-gray-600"
                      data-testid={`text-event-time-${index}`}
                    >
                      {event.time}
                    </div>
                  </div>
                  <h4 
                    className="text-xl font-semibold mb-3"
                    data-testid={`text-event-title-${index}`}
                  >
                    {event.title}
                  </h4>
                  <p 
                    className="text-gray-600 text-sm mb-4"
                    data-testid={`text-event-description-${index}`}
                  >
                    {event.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span 
                      className={`font-semibold ${event.isFree ? 'text-green-600' : 'text-cattus-purple'}`}
                      data-testid={`text-event-price-${index}`}
                    >
                      {formatPrice(event.price, event.isFree)}
                    </span>
                    <Button
                      variant="ghost"
                      className="text-cattus-purple hover:text-cattus-purple-light font-semibold text-sm"
                      data-testid={`button-event-info-${index}`}
                    >
                      Más info →
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Newsletter Subscription */}
        <div className="gradient-cattus rounded-3xl p-8 text-white text-center">
          <h3 
            className="text-2xl font-bold mb-4"
            data-testid="text-newsletter-title"
          >
            ¡No te pierdas nuestros eventos!
          </h3>
          <p 
            className="text-lg mb-6"
            data-testid="text-newsletter-description"
          >
            Suscríbete a nuestro boletín para recibir información sobre próximos eventos y ofertas especiales.
          </p>
          <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto flex gap-4">
            <Input
              type="email"
              placeholder="tu@email.com"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
              required
              data-testid="input-newsletter-email"
            />
            <Button
              type="submit"
              disabled={newsletterMutation.isPending}
              className="bg-white text-cattus-purple px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              data-testid="button-newsletter-subscribe"
            >
              <Send className="mr-2 h-4 w-4" />
              {newsletterMutation.isPending ? "..." : "Suscribirse"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
