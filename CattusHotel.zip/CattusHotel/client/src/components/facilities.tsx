export default function Facilities() {
  const facilities = [
    {
      title: "Suites Premium",
      description: "Habitaciones espaciosas con juguetes, rascadores y vistas al jardín",
      image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    },
    {
      title: "Área de Juegos",
      description: "Espacios amplios para ejercicio y socialización supervisada",
      image: "https://images.unsplash.com/photo-1555685812-4b943f1cb0eb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    },
    {
      title: "Clínica Veterinaria",
      description: "Consultorio completamente equipado para cuidados médicos",
      image: "https://pixabay.com/get/gaa4d61d53983ad177d43c6d6d271734ceaef6421393bfa0c6d0cd4b572c611e565105b57ddf32a08c9e69f4d19ac4f6210e13dfcc49aa3d2969f4eb2d26cdab4_1280.jpg",
    },
  ];

  return (
    <div id="facilities" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 
            className="text-4xl font-bold text-gray-900 mb-4"
            data-testid="text-facilities-title"
          >
            Nuestras Instalaciones
          </h2>
          <p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            data-testid="text-facilities-subtitle"
          >
            Espacios diseñados especialmente para el bienestar y comodidad de tu gato
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((facility, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              data-testid={`card-facility-${index}`}
            >
              <img
                src={facility.image}
                alt={facility.title}
                className="w-full h-48 object-cover"
                data-testid={`img-facility-${index}`}
              />
              <div className="p-6">
                <h3 
                  className="text-xl font-semibold mb-2"
                  data-testid={`text-facility-title-${index}`}
                >
                  {facility.title}
                </h3>
                <p 
                  className="text-gray-600"
                  data-testid={`text-facility-description-${index}`}
                >
                  {facility.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
