import { Stethoscope, User, Scissors, Home } from "lucide-react";

export default function Team() {
  const teamMembers = [
    {
      name: "Dra. María González",
      role: "Veterinaria Fundadora",
      description: "15 años de experiencia en medicina felina y comportamiento animal",
      image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      icon: User,
      color: "text-cattus-purple",
      bgColor: "bg-cattus-purple",
    },
    {
      name: "Dr. Carlos Ramírez",
      role: "Especialista en Medicina Preventiva",
      description: "Certificado en medicina interna felina y cuidados intensivos",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      icon: Stethoscope,
      color: "text-cattus-blue",
      bgColor: "bg-cattus-blue",
    },
    {
      name: "Ana Martínez",
      role: "Especialista en Estética Felina",
      description: "Técnica certificada en grooming y spa para gatos",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      icon: Scissors,
      color: "text-cattus-purple-light",
      bgColor: "bg-cattus-purple-light",
    },
    {
      name: "Luis Torres",
      role: "Coordinador de Cuidado Domiciliario",
      description: "Especialista en servicios personalizados y reducción de estrés",
      image: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      icon: Home,
      color: "text-green-600",
      bgColor: "bg-green-500",
    },
  ];

  return (
    <div className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 
            className="text-4xl font-bold text-gray-900 mb-4"
            data-testid="text-team-title"
          >
            Nuestro Equipo
          </h2>
          <p 
            className="text-xl text-gray-600"
            data-testid="text-team-subtitle"
          >
            Profesionales apasionados dedicados al cuidado de tu gato
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <div 
              key={index}
              className="text-center group"
              data-testid={`card-team-member-${index}`}
            >
              <div className="relative mb-6">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-32 h-32 rounded-full mx-auto object-cover shadow-lg group-hover:shadow-xl transition-shadow"
                  data-testid={`img-team-member-${index}`}
                />
                <div className={`absolute -bottom-2 -right-2 ${member.bgColor} text-white p-2 rounded-full`}>
                  <member.icon className="text-sm" size={16} />
                </div>
              </div>
              <h3 
                className="text-xl font-semibold mb-2"
                data-testid={`text-team-member-name-${index}`}
              >
                {member.name}
              </h3>
              <p 
                className={`${member.color} font-medium mb-2`}
                data-testid={`text-team-member-role-${index}`}
              >
                {member.role}
              </p>
              <p 
                className="text-gray-600 text-sm"
                data-testid={`text-team-member-description-${index}`}
              >
                {member.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
