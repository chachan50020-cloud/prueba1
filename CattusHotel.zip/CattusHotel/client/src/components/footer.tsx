import { Cat, Phone, Mail, MapPin, Clock, Facebook, Instagram, MessageCircle, Youtube } from "lucide-react";

export default function Footer() {
  const services = [
    { name: "Hospedaje", href: "#servicios" },
    { name: "Estética", href: "#servicios" },
    { name: "Medicina Preventiva", href: "#servicios" },
    { name: "Cuidado en Casa", href: "#servicios" },
  ];

  const contactInfo = [
    {
      icon: Phone,
      text: "(+57) 300 123 4567",
      href: "tel:+573001234567",
    },
    {
      icon: Mail,
      text: "info@cattushotel.com",
      href: "mailto:info@cattushotel.com",
    },
    {
      icon: MapPin,
      text: "Calle 123 #45-67\nBogotá, Colombia",
      href: "#",
    },
    {
      icon: Clock,
      text: "Lun-Dom: 7:00 AM - 8:00 PM",
      href: "#",
    },
  ];

  const socialLinks = [
    {
      icon: Facebook,
      href: "#",
      label: "Facebook",
    },
    {
      icon: Instagram,
      href: "#",
      label: "Instagram",
    },
    {
      icon: MessageCircle,
      href: "#",
      label: "WhatsApp",
    },
    {
      icon: Youtube,
      href: "#",
      label: "TikTok",
    },
  ];

  const scrollToSection = (href: string) => {
    if (href.startsWith("#")) {
      const element = document.getElementById(href.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <footer className="bg-gray-900 text-white py-16" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-4">
              <Cat className="text-cattus-purple text-2xl mr-2" data-testid="footer-logo-icon" />
              <span className="text-xl font-bold" data-testid="footer-logo-text">
                Cattus Hotel
              </span>
            </div>
            <p 
              className="text-gray-400 mb-4 max-w-md"
              data-testid="footer-description"
            >
              El hogar perfecto para tu minino. Cuidado profesional, amor incondicional y la tranquilidad que tu gato merece.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="text-gray-400 hover:text-cattus-purple transition-colors"
                  aria-label={social.label}
                  data-testid={`link-social-${social.label.toLowerCase()}`}
                >
                  <social.icon size={24} />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 
              className="text-lg font-semibold mb-4"
              data-testid="footer-services-title"
            >
              Servicios
            </h4>
            <ul className="space-y-2 text-gray-400">
              {services.map((service, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(service.href)}
                    className="hover:text-white transition-colors text-left"
                    data-testid={`link-footer-service-${index}`}
                  >
                    {service.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 
              className="text-lg font-semibold mb-4"
              data-testid="footer-contact-title"
            >
              Contacto
            </h4>
            <ul className="space-y-2 text-gray-400">
              {contactInfo.map((contact, index) => (
                <li key={index} className="flex items-start">
                  <contact.icon className="mr-2 mt-1 flex-shrink-0" size={16} />
                  <span 
                    className="text-sm whitespace-pre-line"
                    data-testid={`text-contact-${index}`}
                  >
                    {contact.text}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p data-testid="footer-copyright">
            &copy; 2024 Cattus Hotel para Gatos. Todos los derechos reservados.
          </p>
          <p 
            className="mt-2 text-sm"
            data-testid="footer-tagline"
          >
            Diseñado con 💜 para el bienestar de los felinos colombianos
          </p>
        </div>
      </div>
    </footer>
  );
}
