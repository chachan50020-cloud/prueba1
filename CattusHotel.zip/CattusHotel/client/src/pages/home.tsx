import Navigation from "@/components/navigation";
import Hero from "@/components/hero";
import Facilities from "@/components/facilities";
import History from "@/components/history";
import Team from "@/components/team";
import Testimonials from "@/components/testimonials";
import Services from "@/components/services";
import Partnerships from "@/components/partnerships";
import Events from "@/components/events";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <section id="inicio">
        <Hero />
        <Facilities />
        <History />
        <Team />
        <Testimonials />
      </section>

      <section id="servicios">
        <Services />
      </section>

      <section id="alianzas">
        <Partnerships />
      </section>

      <section id="eventos">
        <Events />
      </section>

      <Footer />
    </div>
  );
}
